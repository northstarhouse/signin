import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Switch, Route } from "wouter";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="max-w-md mx-auto bg-white min-h-screen shadow-lg">
        <Switch>
          <Route path="/" component={() => <div>Welcome to North Star Check-In</div>} />
        </Switch>
      </div>
    </QueryClientProvider>
  );
}

export default App;
